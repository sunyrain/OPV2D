# OPV-DB v2.0.0 — data release

OPV-DB links reported organic photovoltaic performance with material identities,
molecular representations, device structures and preparation information. The
primary resource is the standard-binary collection. Ternary and indoor
collections provide additional observations with partial literature coverage.

## Data tables

| File | Rows | Columns | Source DOIs | Content |
|---|---:|---:|---:|---|
| data/binary.csv | 32,778 | 37 | 7,360 | Primary standard-binary observations |
| data/binary_strict_performance.csv | 27,863 | 37 | 6,873 | Nested numerical-consistency subset of binary.csv |
| data/binary_strict_molecular.csv | 19,299 | 37 | 5,193 | Nested strict-performance subset with both material SMILES |
| data/binary_supplement.csv | 32,778 | 47 | 7,360 | 45 additional fields plus id and doi; same binary observations |
| data/ternary.csv | 2,588 | 68 | 461 | Ternary photovoltaic observations |
| data/indoor.csv | 1,678 | 57 | 166 | Indoor photovoltaic observations |
| data/materials_reference.csv | 4,988 | 7 | — | Supporting material identities and molecular representations |

The binary table keeps the 37 column names and order used in v1.1.0. Its two
strict subsets use exactly the same columns and original cell values. To add
preparation and source detail to any binary table, join binary_supplement.csv
by the text identifier id and confirm doi. The supplement and the strict subsets
add no new observations.

The specialist tables begin with observation_id and doi, followed by materials,
performance, illumination, statistics, preparation/device information and source detail.
The material reference omits nonspecific numeric labels and generic identifiers
without a standalone material identity. Original labels in source-linked device
observations are retained.

## Reading and interpreting the data

CSV files use UTF-8 with BOM. Read identifiers and DOI values as strings. Units
and field definitions are given in field_dictionary.csv; its binary definitions
also apply to both strict-subset files. Original text qualifications are retained.
Blank and documented missing-token values do not imply zero or absence of a treatment.
Source qualifiers and discrepancies are recorded in source_notes. Additional preparation
details are retained in processing_notes. Web table locators preserve the source web
representation and may differ from printed table numbering. Observation identifiers
remain stable for joining records and distinguishing conditions or statistics.

The primary table represents experimental binary organic single-junction devices
within the standard one-sun, small-area scope. Explicitly identified devices with
effective area >=1 cm2, modules, tandem devices, simulations and incompatible
material or illumination scope are excluded. Missing area or irradiance alone
is not an exclusion criterion. Nominal one-sun irradiance is 100 mW/cm2.

The ternary collection excludes identified binary controls prepared without a third active material.
The indoor table preserves reported illumination conditions and units. Lux is
not converted to irradiance without a supported spectrum. These two specialist
collections have partial coverage because literature collection focused on binary devices.

The three observation tables total 37,044 rows and share some source studies and
observations; this sum is not a deduplicated experiment count. Their source-DOI union
contains 7,523 identifiers. Distinguish observations by composition, preparation,
measurement conditions, statistical meaning and source location when combining tables.

The binary pce column retains the reported value associated with each record; it is
not uniformly a champion-PCE selection. Mean, best/champion and unlabelled values
are distinguished through pce_avg, pce_best, metric_statistics and source_notes
where available. The pce_best column alone does not establish a champion label.
Do not substitute a best PCE into mean Voc/Jsc/FF without matching the statistic.
Ternary and indoor tables retain separate statistical observations, so a mean and
a best/champion value for the same experimental condition can occupy separate rows.
metric_statistics and ratio_component_order may contain JSON or plain text;
parse valid JSON where present and otherwise preserve the text. Material-reference
energy levels are not necessarily measurements from the linked device study.
Polymer SMILES generally represent finite repeat-unit surrogates. The specialist collections report material names and roles without assigned SMILES.
Molecular structures remain available in the binary and material-reference tables;
name-only matches are not supplied as specialist structure assignments.

## Binary subsets

validation/subset_rules.json specifies the strict-performance and strict-molecular
selection rules. The performance subset requires the specified source and material
fields, finite performance values, physical ranges, and a relative PCE difference
of at most 2% under nominal 100 mW/cm2, followed by the documented duplicate-key rule.
The molecular subset additionally requires both material SMILES to be present.
Selection compliance is not independent validation of extraction or chemical identity.
The two equation-derived columns in binary.csv are diagnostics and do not replace
reported PCE or establish observed irradiance.

## Literature sources

Source DOIs are retained in the observation tables. Additional source descriptions
are provided in the binary supplement and specialist tables where available.
Retained sources include articles with verified online publication dates as late
as March 2026. This describes literature coverage rather than a common search
cutoff. Publication-issue dates can be later than online dates.

## Changes from v1.1.0

The previous primary export contained 39,998 records. Of those IDs, 32,745 remain
in the current binary collection, and 33 binary IDs were added, giving 32,778 rows.
Other earlier IDs were associated with specialist collections, merged as repeated
observations, excluded under the binary scope, or not retained because inclusion
evidence was insufficient. The specialist collections are not a one-to-one
partition of the earlier primary table. Existing fields retain their original
schema; additional information is delivered through the linked supplement.

Previous data version: https://doi.org/10.5281/zenodo.22177960.
Version-series identifier: https://doi.org/10.5281/zenodo.20841542.
The version-specific DOI is https://doi.org/10.5281/zenodo.23951239.
CITATION.cff contains the citation metadata.

## Files and license

This archive has 13 files: seven data CSVs; this README, the field dictionary,
CITATION.cff, LICENSE and THIRD_PARTY_ATTRIBUTION.md; and the subset-rule definition. Data are licensed under CC BY 4.0.
Third-party material-reference attribution remains in THIRD_PARTY_ATTRIBUTION.md.

File correction, 8 November 2026: 69 binary observations have corrections to material roles, identities or their linked fields; source notes were clarified. One unsupported control FF was removed. The primary row count is unchanged; both strict subsets were regenerated.
